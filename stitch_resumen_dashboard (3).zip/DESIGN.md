# Design System Strategy: The Luminous Executive

## 1. Overview & Creative North Star
This design system is built upon the North Star of **"The Luminous Executive."** In an era of cluttered data dashboards, this system prioritizes clarity through light, breathability, and an editorial hierarchy. It moves away from the rigid, boxed-in nature of traditional SaaS platforms, instead favoring a "boundless" UI where information is grouped by tonal shifts and spatial relationships rather than heavy lines.

The aesthetic is "Editorial Intelligence"—combining the authoritative weight of premium typography with the soft, layered depth of modern glass surfaces. By utilizing intentional asymmetry (such as offset card layouts and floating action bars), the UI feels bespoke and high-end, signaling to the user that the AI-powered insights within are sophisticated and precise.

## 2. Colors & Surface Logic
The palette is rooted in a refined neutral base, punctuated by a vibrant, high-energy primary accent.

### Core Palette
- **Primary:** `#702ae1` (Vibrant Purple) — Used for core brand identity and primary actions.
- **Secondary:** `#7742a6` — Used for secondary data points and supporting components.
- **Background:** `#f5f7f9` — A cool, clean gray that provides a professional foundation.
- **Surface (Lowest):** `#ffffff` — The "white card" standard for primary content containers.

### The "No-Line" Rule
Traditional 1px borders are strictly prohibited for sectioning. Structural boundaries must be achieved through **Tonal Transition**. Use `surface-container-low` (`#eef1f3`) to define regions of the app, allowing white `surface-container-lowest` cards to sit atop them. This creates a soft, modern lift that feels integrated rather than partitioned.

### Glass & Gradient Signature
To move beyond a generic dashboard feel:
- **Hero Actions:** Use a subtle linear gradient for primary buttons, transitioning from `primary` (#702ae1) to `primary-container` (#b28cff) at a 135-degree angle.
- **Floating Elements:** Use Glassmorphism for tooltips and floating menus. Apply `surface` colors at 80% opacity with a `20px` backdrop-blur. This adds "soul" and professional polish.

## 3. Typography
The typography system uses a dual-font approach to balance character with readability.

*   **Display & Headlines (Plus Jakarta Sans):** Chosen for its modern, geometric structure. Used in large scales for "Editorial Moments" where data needs to feel like a headline.
*   **Body & Labels (Inter):** The workhorse of the system. Its high x-height ensures clarity in dense data tables and small labels.

**Scale Philosophy:**
- **Display-LG (3.5rem):** For hero metrics that define the business's success.
- **Headline-SM (1.5rem):** For card titles and section headers.
- **Label-SM (0.6875rem):** All-caps with increased letter-spacing (0.05em) for category headers to create an "Executive Report" feel.

## 4. Elevation & Depth
Elevation in this system is not about height, but about **Environmental Layering**.

*   **The Layering Principle:** Place primary cards (`surface-container-lowest`) on top of section backgrounds (`surface-container-low`). The subtle shift from `#ffffff` to `#eef1f3` is all the "border" the human eye needs to perceive a container.
*   **Ambient Shadows:** For floating elements (like the sidebar active state or modals), use a 3-layer diffused shadow:
    *   `0px 4px 20px rgba(112, 42, 225, 0.04)` (A tinted purple shadow to mimic light passing through glass).
*   **The Ghost Border:** If a visual anchor is needed (e.g., in high-density data tables), use `outline-variant` at 15% opacity. Never use solid, high-contrast lines.

## 5. Components

### Cards & Metrics
*   **Logic:** Cards must never use dividers. Separate header, body, and footer through the Spacing Scale (typically `spacing-6` between blocks).
*   **Metrics:** Hero numbers should use `display-sm` in `on-surface` with a supporting `label-md` in `primary` to highlight growth or change.

### Buttons & Toggles
*   **Primary Button:** Rounded-xl (`1.5rem`), gradient-filled, with `on-primary` text.
*   **Toggle Switch:** Use `primary` for the "on" state. The track should be `surface-container-high` and the thumb should always be `surface-container-lowest` to ensure it "pops" off the track.

### Status Badges
*   **Success:** `tertiary-container` background with `on-tertiary-container` text.
*   **Danger:** `error_container` background with `on-error_container` text.
*   **Neutral:** `surface-container-highest` background with `on-surface-variant` text.
*   *Note: All badges should use `rounded-full` and `label-sm` font for a pill-like, professional appearance.*

### Input Fields
*   **Style:** No borders. Use `surface-container-low` as the background with a `rounded-md` corner. On focus, transition the background to `surface-container-lowest` and add a `1px` ghost border using `primary_dim`.

## 6. Do's and Don'ts

### Do
*   **DO** use whitespace as a structural element. If an interface feels cramped, increase spacing before adding a line.
*   **DO** use "Primary Tinting" in shadows. A shadow with a hint of purple (#7C3AED) feels more premium than a muddy gray shadow.
*   **DO** align icons to a 24px grid but allow the containers to be fluid.

### Don't
*   **DON'T** use pure black (#000000) for text. Use `on-surface` (#2c2f31) to maintain the soft editorial feel.
*   **DON'T** use 90-degree corners. Everything must have a minimum of `rounded-sm` to maintain the "Luminous" approachable vibe.
*   **DON'T** use high-contrast zebra-striping in tables. Use subtle `0.5px` ghost-borders or nothing at all.